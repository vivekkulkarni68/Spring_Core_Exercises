package com.rits;

public abstract class MagicBoxImpl implements MagicBox {
	
	public MagicBoxImpl() {
		super();
		
	}

	@Override
	public abstract String showContents(String val);
	

}
