package bank.server;

public interface Bank {
	int withdraw(int amount , int acctNo);

}
