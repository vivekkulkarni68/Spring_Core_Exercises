package com.rits;

public interface MagicBox {
	String getContents();

}
