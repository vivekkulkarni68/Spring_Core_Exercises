package com.rits;

public interface Shape {
	float getArea();
	String getShape();
	float getPerimiter();
	double PI=3.14f;

}
