package bank.server.internal;

public class InvalidInterestRateException extends Exception {

	public InvalidInterestRateException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
