package com.rkit;

public interface Bank {
	int withdraw(int amount);
	int deposit(int amount);

}
