package com.rkit;
public class Umbrella implements Product {

	@Override
	public String getDescription() {
		return "Umbrella";
	}

	@Override
	public int getPrice() {
		return 130;
	}

}
