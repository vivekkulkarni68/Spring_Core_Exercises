package com.rkit;

public interface Product {
	String getDescription();
	int getPrice();

}
