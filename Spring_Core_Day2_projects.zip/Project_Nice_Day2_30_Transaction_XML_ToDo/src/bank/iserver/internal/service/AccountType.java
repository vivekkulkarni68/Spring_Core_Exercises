package bank.iserver.internal.service;

public interface AccountType {

}
