package bank.server;

import java.util.Collection;
import java.util.Map;

import bank.iserver.internal.service.AccountType;

public interface Bank {
	int withdraw(int amount , int acctNo);
	int deposit(int amount, int acctNo);
	Collection<AccountType> showAccountServices();
	Map<String,AccountType> showAccountServicesByName();
	void transfer(int acctFrom, int amount, int acctTo);

}
