package bank.server.internal;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import org.springframework.transaction.annotation.Transactional;

import bank.iserver.internal.service.AccountRepository;
import bank.iserver.internal.service.AccountType;
import bank.server.*;


import bank.server.Bank;
@Transactional
public class BankImpl implements Bank {
	
    AccountRepository accountRepo;
    String bankName;
    int branchCode;
    Collection<AccountType> accountTypes = new ArrayList<AccountType>();
    
	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public int getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(int branchCode) {
		this.branchCode = branchCode;
	}

	public AccountRepository getAccountRepo() {
		return accountRepo;
	}

	public void setAccountRepo(AccountRepository accountRepo) {
		this.accountRepo = accountRepo;
	}

	private BankImpl() {
		super();
		System.out.println("Private constructor called");
		// TODO Auto-generated constructor stub
	}

	private BankImpl(AccountRepository accountRepo,Collection<AccountType> acctTypes) {
		super();
		this.accountRepo = accountRepo;
		this.accountTypes = acctTypes;
		System.out.println("Private Overloaded constructor called");
	}

	@Override
	public int withdraw(int amount, int acctNo) {
		Account acct = accountRepo.findAccountByAcctNumber(acctNo);
		if(acct.getBalance() > amount){
			acct.setBalance(acct.getBalance()-amount);
			System.out.println("Transfering Rs."+amount+" from "+acct);
			 
			accountRepo.updateAccount(acct);
		}
		else
			System.out.println("Insufficient Funds Exception");
		return acct.getBalance();

	}

	@Override
	public Collection<AccountType> showAccountServices() {
		return accountTypes;
	}
	public Map<String, AccountType> showAccountServicesByName() {
		return null;
	}

	@Override
	public int deposit(int amount, int acctNo) {
		Account acctTarget = accountRepo.findAccountByAcctNumber(acctNo);	
		acctTarget.setBalance(acctTarget.getBalance()+amount);
		if(1==1)//just trying to show that the automicity will be broken due to this exception.
			throw new RuntimeException("Failed to deposit into "+acctTarget);
		accountRepo.updateAccount(acctTarget);
		
		return acctTarget.getBalance();
	}

	@Override
	@Transactional 
	//same can be declared at the class level if this annotation is not written
	//then the automicity will be lost and deposit fails but withdraw succeeds leaving data inconsistent.
	public void transfer(int acctFrom, int amount, int acctTo) {
		withdraw(amount,acctFrom);
        deposit(amount, acctTo);
		
		
	}

}
