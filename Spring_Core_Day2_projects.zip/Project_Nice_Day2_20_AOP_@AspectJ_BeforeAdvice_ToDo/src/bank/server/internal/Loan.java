package bank.server.internal;

public interface Loan {

}
