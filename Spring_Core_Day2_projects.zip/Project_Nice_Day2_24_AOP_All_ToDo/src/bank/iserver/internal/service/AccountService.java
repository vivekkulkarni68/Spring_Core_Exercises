package bank.iserver.internal.service;

public interface AccountService {
	int updateBalance(int amount);

}
