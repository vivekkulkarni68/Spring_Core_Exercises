package bank.iserver.internal.service;

abstract public class AccountServiceClass {
	abstract public int updateBalance(int amount);

}
